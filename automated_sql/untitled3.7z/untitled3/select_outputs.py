def output_column_comparison(file_name,date,file,target_table,source_table,from_source,from_target,source_database,source_schema,main_path,output_name,link):
    with open(main_path+'\\'+ '{} - Column comparison.sql'.format(target_table), 'w') as f:
        f.write('''/****** STM:''' + file_name + ''' ver:  Script Date:''' + str(date) + '''
STM Link:'''+link+'''
SourceTable   '''+source_database+'.'+source_schema+'.'+source_table+'''
SourceColumn

TargetTable   '''+target_table+'''ALL
TargetColumn ******/

declare @BatchID int

-- Select column for test from source.
;with [Source] as
    (select'''+from_source+'''

    from '''+source_database+'.'+source_schema+'.'+source_table+'''
),

-- Select column for test from target table.
[Target] as
(select '''+from_target+'''
from [dm_test].[dbo].['''+target_table+'''ALL]

)
-----------------------------------------------
-- Select incorrect data

select 'Error: Record from Source doesnt exists in Target'Error , * from
( -- Everything from TransformedSource, except Target
       select * from [Source]
       except
       select * from [Target]
) e1
union all
select 'Error: Record from Target doesnt exists in Source'Error , * from
(-- Everything from Target, except TransformedSource
       select * from [Target]
       except
       select * from [Source]
) e2
declare @Rows int = @@Rowcount,
@Message varchar(255)
set @Message ='Columns contain invalid data;'+ convert(varchar(25),@Rows)
if @Rows>0   raiserror(@Message, 16, -99)

 ''')
    f.close()



def output_column_header(file_name,date,target_table,source_table,target,source_database,source_schema,main_path,link):
    with open(main_path+'\{} - Column header.sql'.format(target_table), 'w') as f:
        f.write('''/****** STM:''' + file_name + ''' ver:  Script Date:''' + str(date) + '''
STM Link: '''+link+'''
SourceTable   ''' + source_database + '.' + source_schema + '.' + source_table + '''
TargetTable   ''' + target_table + '''ALL


******/

declare @BatchID int

set nocount on
declare @STM_O table(ColumnName varchar(50))
insert into @STM_O (ColumnName) values \n'''+target+'''

-- get columns with differs(if exists)
declare @errorColumns varchar(755) = ''
declare @countFlag int = 0

select
@errorColumns = @errorColumns + COLUMN_NAME + '; '
from INFORMATION_SCHEMA.COLUMNS
where TABLE_NAME like '%'''+source_table+'''%' and TABLE_SCHEMA='dbo' and COLUMN_NAME not in (select * from @STM_O)

--set @countFlag = 1 if count(stm) <> count(table)
if((select count(*) from @STM_O) <> (select count(*) from INFORMATION_SCHEMA.COLUMNS where TABLE_NAME like '%'''+source_table+'''%'))
	set @countFlag = 1

 --check conditions, create error message, raise error
if (select len(@errorColumns)) <> 0 or @countFlag = 1
begin
	declare @errorMsg varchar(755) = ''

	if (select len(@errorColumns)) <> 0
		set @errorMsg = 'Column(s) name are differ from STM. Please check table columns: ' + @errorColumns

	if @countFlag = 1
		set @errorMsg = 'Number of columns are differ from STM. ' + @errorMsg

	raiserror(@errorMsg, 16, -99)
end


 ''')
    f.close()

