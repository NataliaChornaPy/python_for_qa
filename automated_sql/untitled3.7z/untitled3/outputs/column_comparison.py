import xlrd
import select_outputs as s
import os,datetime
import os.path
import re
from outputs import path,link,file_name

save_path=path()
file_name=file_name()
link=link()
main_path = save_path + '\STAGING_FILE_scripts'
if not os.path.exists(main_path):
    os.makedirs(main_path)
    folder = os.path.dirname(main_path)

else:
    folder = main_path
date=datetime.date.today()
rb = xlrd.open_workbook(file_name)
sheet = rb.sheet_by_index(0)
b=0
amount=0
if os.path.exists('OUTPUT_columncomparison_SOURCE_SHOULD_BE_DELETED.sql'):
    os.remove('OUTPUT_columncomparison_SOURCE_SHOULD_BE_DELETED.sql')
if os.path.exists('OUTPUT_columncomparison_TARGET_SHOULD_BE_DELETED.sql'):
    os.remove('OUTPUT_columncomparison_TARGET_SHOULD_BE_DELETED.sql')
for rownum in range(5,sheet.nrows):

    row = sheet.row_values(rownum)
    row = sheet.row_values(rownum)
    target_table=row[1].split('@')[0]
    print target_table
    target_table= str(target_table).replace('_EFCPRMS_','_')
    pattern_abbr = re.compile('\d+')
    abbr = re.findall(pattern_abbr, target_table)
    output_name=abbr[0]+'_'+abbr[1]
    print output_name
    # if 'EFCPRMS_' in str(target_table.decode('utf-8')):
    #     target_table2=target_table.replace('EFCPRMC_',',')
    # print target_table2
    target_column = row[2]
    target_length = row[5]
    source_database = row[7]
    source_schema=row[8]
    source_table = row[9]
    source_column = row[10]
    with open('OUTPUT_columncomparison_SOURCE_SHOULD_BE_DELETED.sql', 'a') as f:
        f.write("           isnull(convert(varchar(255),{}), '') as [{}],\n".format(source_column,source_column))
        f.close()
    with open('OUTPUT_columncomparison_TARGET_SHOULD_BE_DELETED.sql', 'a') as f:
        f.write("           [" + target_column + "],\n")
        f.close()
    amount += 1

d=open('OUTPUT_columncomparison_SOURCE_SHOULD_BE_DELETED.sql', 'r')
from_source=d.read()[:-2]
# print file[:-2]
from_target2=open('OUTPUT_columncomparison_TARGET_SHOULD_BE_DELETED.sql', 'r')
from_target=from_target2.read()[:-2]
# print output_name, target_table
s.output_column_comparison(file_name,date,file,target_table,source_table,from_source,from_target,source_database,source_schema,main_path,output_name,link)

print "Commom column number is ----",amount