import xlrd
import os,datetime,os.path
from outputs import path,link,file_name

b=0
amount=0
save_path=path()
file_name=file_name()
link=link()
date=datetime.date.today()
rb = xlrd.open_workbook(file_name)
sheet = rb.sheet_by_index(0)

main_path = save_path + '\STAGING_FILE_scripts'
if not os.path.exists(main_path):
    os.makedirs(main_path)
    folder = os.path.dirname(main_path)
else:
    folder = main_path

for rownum in range(5,sheet.nrows):
    row = sheet.row_values(rownum)
    target_table = row[1].split('@')[0]
    target_table = str(target_table).replace('_EFCPRMS_', '_')
    print target_table
    target_column= row[2]
    target=row[6]
    source_table = row[9]
    columns=[]
    amount+=1
    with open(main_path+'\{} - RowCount.sql'.format(target_table), 'w') as f:
        f.write('''/****** STM:'''+file_name+''' ver:  Script Date:'''+str(date)+'''
    STM Link: https: '''+link+'''

    SourceTable '''+source_table+'''
    SourceColumn  N/A

    TargetTable '''+target_table+'''
    TargetColumn   ******/

    declare @BatchID varchar(10)

    if exists(
    select count(*) from dm_staging.outbound.'''+source_table+'''
    except
    select count(*) from [dm_test].[dbo].['''+target_table+'''ALL]
        )
    raiserror(\''''+source_table+'''.[RowCount] <> Output.[RowCount];', 16, -99)''')
        f.close()

print "Common column number is ----",amount
