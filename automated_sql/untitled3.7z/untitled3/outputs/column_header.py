import xlrd
import select_outputs as s
import os,datetime
import os.path
from outputs import path,link,file_name

save_path=path()
file_name=file_name()
link=link()
main_path = save_path + '\STAGING_FILE_scripts'
if not os.path.exists(main_path):
    os.makedirs(main_path)
    folder = os.path.dirname(main_path)
else:
    folder = main_path
date=datetime.date.today()
rb = xlrd.open_workbook(file_name)
sheet = rb.sheet_by_index(0)
b=0
amount=0
if os.path.exists('OUTPUT_header_target_SHOULD_BE_DELETED.sql'):
    os.remove('OUTPUT_header_target_SHOULD_BE_DELETED.sql')

for rownum in range(5,sheet.nrows):

    row = sheet.row_values(rownum)
    row = sheet.row_values(rownum)
    target_table=row[1].split('@')[0]
    target_table = str(target_table).replace('_EFCPRMS_', '_')
    print target_table

    target_column = row[2]
    target_length = row[5]
    source_database = row[7]
    source_schema=row[8]
    source_table = row[9]

    source_column = row[10]
    with open('OUTPUT_header_target_SHOULD_BE_DELETED.sql', 'a') as f:
        f.write("           ('" + target_column + "'),\n")
        f.close()
    amount += 1

e=open('OUTPUT_header_target_SHOULD_BE_DELETED.sql', 'r')
target=e.read()[:-2]
print target_table
s.output_column_header(file_name,date,target_table,source_table,target,source_database,source_schema,main_path,link)

print "Commom column number is ----",amount