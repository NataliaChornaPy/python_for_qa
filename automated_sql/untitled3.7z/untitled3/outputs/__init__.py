def path():
    save_path = 'C:\Users\Natalia_Chorna\PycharmProjects\untitled3\scripts'
    return save_path


def link():
    links = '''https://elementfinancialcorporation.sharepoint.com/EPAM-EFC-PRMS/DocCentre/_layouts/15/WopiFrame.aspx?sourcedoc=%7B81E2431E-8622-413F-8766-283C0B0FDD6E%7D&file=0018_EFCPRMS_8122_Profile_Landing_Staging_STM.xlsx&action=default
    '''
    return links

def file_name():
    file_name = '0012_EFCPRMS_9937_Service_Card_Header_WEX_Staging_File_STM.xlsx'
    return file_name