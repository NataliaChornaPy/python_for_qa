import xlrd
import selects as s
import datetime
import os.path
from inputs import path,link,file_name
b=0
amount=0
save_path=path()
file_name=file_name()
link=link()
main_path = save_path + '\data_length_check'
if not os.path.exists(main_path):
    os.makedirs(main_path)
    folder = os.path.dirname(main_path)
else:
    folder = main_path

date=datetime.date.today()
rb = xlrd.open_workbook(file_name)
# ---------------------------------------------------------------------------------------------------------
sheet = rb.sheet_by_index(1)
# ---------------------------------------------------------------------------------------------------------

for rownum in range(5,sheet.nrows):
    amount+=1
    row = sheet.row_values(rownum)
    target_table=row[3]
    target_column= row[4]
    target_data_type=row[6]
    source_database = row[9]
    source_table = row[11]
    source_column = row[12]
    target_length=str(row[7])

    target_column = str(target_column.decode('utf-8'))
    target_table = str(target_table.decode('utf-8'))
    # print target_table
    # target_table='Profile_Client_Breakdown'


    if "." in target_length:
        target_length=target_length.split(".")[0]
    elif "," in target_length:
        if int(target_length.split(",")[1])==0:
            target_length = int(target_length.split(",")[0])
        else:
            target_length = int(target_length.split(",")[0]) + 1
    else:
        target_length=str(row[7])
    if target_length=='':
        print "Script wasn't created for target column because of empty length value :",target_column
        continue
    else:
        print target_table
        if target_data_type == 'varchar' or target_data_type == 'char' or target_column == 'nvarchar':
            s.datalength(file_name,date,"datalength",target_table,target_column,source_table,source_column,target_length,main_path,link)
            b+=1
        else:
            s.datalength(file_name,date,"len",target_table, target_column, source_table, source_column, target_length,main_path,link)
            b+=1

print "Common column number is ----",amount
print "Number of cteated files for LENGTH check is---",b