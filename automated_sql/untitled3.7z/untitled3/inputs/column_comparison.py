import xlrd
import selects as s
import datetime
import os.path
from inputs import path,link,file_name
b=0
amount=0
save_path=path()
file_name=file_name()
link=link()
main_path = save_path + '\column_comparison'
if not os.path.exists(main_path):
    os.makedirs(main_path)
    folder = os.path.dirname(main_path)
else:
    folder = main_path

date=datetime.date.today()
rb = xlrd.open_workbook(file_name)
# ---------------------------------------------------------------------------------------------------------
sheet = rb.sheet_by_index(1)
# ---------------------------------------------------------------------------------------------------------

for rownum in range(5,sheet.nrows):
    amount+=1
    row = sheet.row_values(rownum)
    target_table=row[3]
    target_column= row[4]
    target_data_type=row[6]
    source_database = row[9]
    source_table = row[11]
    source_column = row[12]
    target_length=str(row[7])
    transformation=row[16]
    if (transformation=='' or 'default' in transformation) and str(target_column).upper().lower().strip() <>'originalfilerownumber' and str(target_column).upper().lower().strip() <>'loaddate':
        s.column_comparison(file_name,date,target_table,target_column,main_path,link,source_table,source_column)
        b+=1
print "Common column number is ----",amount
print "Number of cteated files for LENGTH check is---",b