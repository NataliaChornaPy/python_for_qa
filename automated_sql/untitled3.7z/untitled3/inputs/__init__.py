def path():
    save_path = 'C:\Users\Natalia_Chorna\PycharmProjects\untitled3\scripts'
    return save_path


def link():
    links = '''https://elementfinancialcorporation.sharepoint.com/EPAM-EFC-PRMS/DocCentre/_layouts/15/WopiFrame.aspx?sourcedoc=%7BCB8A7856-6024-4190-892A-9C4BC3CFDB6A%7D&file=0011_EFCPRMS-8390_Remarketing_Auction_Sale_Landing_Staging_STM.xlsx&action=default'''
    return links

def file_name():
    file_name = '0011_EFCPRMS-8390_Remarketing_Auction_Sale_Landing_Staging_STM.xlsx'
    return file_name
def ver():
    ver='0.2'
    return ver