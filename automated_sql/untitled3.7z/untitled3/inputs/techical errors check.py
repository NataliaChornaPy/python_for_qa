import xlrd
import selects as s
import datetime
import os.path
from inputs import path,link,file_name
amount=0
save_path=path()
file_name=file_name()
link=link()

main_path = save_path + '\\technical_errors_check'
if not os.path.exists(main_path):
    os.makedirs(main_path)
    folder = os.path.dirname(main_path)
else:
    folder = main_path



date=datetime.date.today()
rb = xlrd.open_workbook(file_name)
# ---------------------------------------------------------------------------------------------------------
sheet = rb.sheet_by_index(1)
# ---------------------------------------------------------------------------------------------------------

for rownum in range(5,sheet.nrows):
    row = sheet.row_values(rownum)
    target_database=row[1]
    target_schema=row[2]
    target_table=row[3]
    target_column= row[4]
    target_data_type=row[6]
    source_database = row[9]
    source_table = row[11]
    source_column = row[12]
    target_length=str(row[7])
    target_nullability=row[8]
    columns=[]
    s.tech(file_name,date,target_table,target_database,target_schema,main_path,link)
    amount += 1
print "Commom column number is ----",amount
