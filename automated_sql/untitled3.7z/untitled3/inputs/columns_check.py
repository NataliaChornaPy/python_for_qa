import xlrd
import selects as s
import os,datetime
import os.path
from inputs import path,link,file_name
b = 0
amount = 0
save_path=path()
file_name=file_name()
link=link()
main_path = save_path + '\columns_check'

if not os.path.exists(main_path):
    os.makedirs(main_path)
    folder = os.path.dirname(main_path)
    # print "Directory Python_for_qa is created"
else:
    folder = main_path

date = datetime.date.today()
rb = xlrd.open_workbook(file_name)
# ---------------------------------------------------------------------------------------------------------
sheet = rb.sheet_by_index(1)
# ---------------------------------------------------------------------------------------------------------

if os.path.exists('Columns_check_prepare.sql'):
    os.remove('Columns_check_prepare.sql')
if os.path.exists('Columns_type_check_prepare.sql'):
    os.remove('Columns_type_check_prepare.sql')
if os.path.exists('metadata_check_prepare.sql'):
    os.remove('metadata_check_prepare.sql')
if os.path.exists('COLUMNS_TYPE_CHECK.sql'):
    os.remove('COLUMNS_TYPE_CHECK.sql')
if os.path.exists('COLUMNS_CHECK.sql'):
    os.remove('COLUMNS_CHECK.sql')

for rownum in range(5, sheet.nrows):
    row = sheet.row_values(rownum)
    target_table = row[3]
    target_column = row[4]
    target_data_type = row[6]
    source_database = row[9]
    source_table = row[11]
    source_column = row[12]
    target_length = str(row[7])
    target_nullability = row[8]
    # target_table = 'Profile_Client_Breakdown'


    # target_column = str(target_column.decode('utf-8'))
    # target_table = str(target_table.decode('utf-8'))
    # print target_table
    if isinstance(target_column,unicode)==True:
        target_column=str(target_column.decode('utf-8'))
        target_data_type=str(target_data_type.decode('utf-8'))

    with open('Columns_check_prepare.sql', 'a') as f:
        f.write("           ('" + target_column + "'),\n")
        f.close()
    with open('Columns_type_check_prepare.sql', 'a') as f:
        f.write("           ('" + str(target_column) + "','" + target_data_type + "'),\n")
        f.close()
    with open('metadata_check_prepare.sql', 'a') as f:
        f.write("         ('" + target_column + "','" + target_nullability + "'),\n")
        f.close()
    amount += 1
d = open('Columns_check_prepare.sql', 'r')
file = d.read()[:-2]
# print file[:-2]
type = open('Columns_type_check_prepare.sql', 'r')
typecolumns = type.read()[:-2]
meta = open('metadata_check_prepare.sql', 'r')
metacolumns = meta.read()[:-2]
s.columns_check(file_name, date, file, target_table,main_path,link)
s.columns_type_check(file_name, date, target_table, typecolumns,main_path,link)
s.metadata(file_name, date, target_table, metacolumns,main_path,link)
print "Commom column number is ----", amount