import xlrd
import selects as s
import datetime
import os.path
from inputs import path,link,file_name
c=0
b=0
save_path=path()
file_name=file_name()
link=link()
main_path = save_path + '\isNumeric_check'
if not os.path.exists(main_path):
    os.makedirs(main_path)
    folder = os.path.dirname(main_path)
else:
    folder = main_path
date=datetime.date.today()
rb = xlrd.open_workbook(file_name)
# ---------------------------------------------------------------------------------------------------------
sheet = rb.sheet_by_index(1)
# ---------------------------------------------------------------------------------------------------------

for rownum in range(5,sheet.nrows):
    row = sheet.row_values(rownum)
    target_table=row[3]
    target_column= row[4]
    target_data_type=row[6]
    target_length_numeric = str(row[7])
    target_length=str(row[7])
    target_nullability=row[8]
    source_database = row[9]
    source_table = row[11]
    source_column = row[12]
    # print target_nullability
    if target_data_type=='numeric':
        s.isNumericCheck(file_name,date,source_table, source_column, target_table, target_column,target_length,main_path,link)
        c+=1

print "Number of cteated files for Target isNumeric check is---",c