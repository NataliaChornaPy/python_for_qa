import xlrd
rb = xlrd.open_workbook('0011_EFCPRMS-8390_Remarketing_Auction_Sale_Landing_Staging_STM.xlsx')
sheet = rb.sheet_by_index(1)
source_columns=[]
b=0
# print sheet.col
for rownum in range(5,sheet.nrows):
    row = sheet.row_values(rownum)
    target_field=row[4]
    # print target_field
    # target_length= str(row[7]).split(".")[0]
    # target_length_numeric = str(row[7]).split(",")[0]
    target_length=str(row[5])
    source_database=row[9]
    source_table=row[11]
    source_column=row[10]
    # print source_column
    # source_columns.append(source_column)

    # print "isnull(convert(varchar(255),{}), '') as [{}],".format(source_column,source_column)
    # with open('OUTput_column_comparison.txt', 'a') as f:
    #        f.write(("isnull(convert(varchar(255),{}), '') as [{}],\n").format(source_column,source_column))
    # f.close
    # print "["+target_field+"],"
    print "('" + target_field + "'),"
    # print "('" + source_column + "'),"
    # print target_field
    # print target_length

