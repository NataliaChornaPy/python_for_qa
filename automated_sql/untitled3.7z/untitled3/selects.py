def datalength(file_name,date,length_function,target_table,target_column,source_table,source_column, target_length,main_path,link):
    with open(main_path+'\Staging - {} - {} - data length check.sql'.format(target_table, target_column), 'w') as f:
        f.write('''/******STM : '''+file_name+''' ver:  Script Date: '''+str(date)+'''
       STM Link: '''+link+'''
       SourceTable {}
       SourceColumn {}

       TargetTable  {}
       TargetColumn {}
    ******/

    declare @BatchID int = ?
    if exists(
            select d.* from dm_staging.outbound.{} d
            where '''.format(source_table, source_column,target_table, target_column,target_table)+'''{}(d.{})>{} and BatchID = @BatchID
            )
    raiserror('{} value exceeds [{}] characters;', 16, -99)'''.format(length_function,target_column,
                                                                               target_length, target_column,
                                                                               target_length))
        f.close()


def nullability(file_name,date,source_table,source_column,target_table,target_column,main_path,link):
    with open(main_path+'\Staging - {} - {} - nullability check.sql'.format(target_table, target_column), 'w') as f:
        f.write(
    '''/******STM: ''' + file_name + ''' ver:  Script Date: ''' + str(date) + '''
       STM Link: '''+link+'''
    SourceTable {}
    SourceColumn {}

    TargetTable  {}
    TargetColumn {}
    ******/

        declare @BatchID int = ?

        if exists(
                select d.* from dm_staging.outbound.{} d
                where d.{} is Null
                and BatchID = @BatchID
                )
        raiserror('{} could not be null', 16, -99)'''.format(source_table, source_column,
                                                                                target_table, target_column,
                                                                                target_table, target_column,
                                                                                target_column))
        f.close()

def tech(file_name,date,target_table,target_database,target_schema,main_path,link):
    with open(main_path+'\Staging - {} - Technical errors check.sql'.format(target_table), 'w') as f:
        f.write('''/******STM: ''' + file_name + ''' ver:  Script Date: ''' + str(date) + '''
     STM Link: '''+link+'''
     SourceTable
     SourceColumn

     TargetTable  {}
     TargetColumn all
******/
     declare @BatchID int = ?
         if exists(
              select * from {}.{}.{}_rejected
              where [SSISErrorCode] <> 0 or [SSISErrorColumn] <> -999
              and BatchID = @BatchID
            )
              raiserror('There are some technical errors in {}_rejected.', 16, -99)'''.format(target_table,target_database,target_schema,target_table,target_table))
    f.close()


def defaulted(file_name,date,source_table,source_column,target_database,target_schema,target_table,target_column,main_path,link):
    with open(main_path+'\Staging - {} - {} - default values.sql'.format(target_table, target_column), 'w') as f:
        f.write('''/******STM: ''' + file_name + ''' ver:  Script Date: ''' + str(date) + '''
    STM Link: '''+link+'''
    SourceTable {}
    SourceColumn {}

    TargetTable  {}
    TargetColumn {}
******/
    declare @BatchID int = ?

    if exists(
        select s.* from {}.{}.{} s
        where s.{} is not null
        and BatchID = @BatchID
             )
    raiserror('{} is not populated with <Null>;', 16, -99)
                                                               '''.format(source_table, source_column,
                                                                                target_table, target_column,
                                                                                target_database,target_schema,target_table,target_column,target_column))
        f.close()

def columns_check(file_name,date,file,target_table,main_path,link):
    with open(main_path+'\Staging - {} - columns check.sql'.format(target_table), 'w') as f:
        f.write('''/****** STM: '''+file_name+''' ver:  Script Date: '''+str(date)+'''
      STM Link: '''+link+'''

    SourceTable
    SourceColumn
    TargetTable  '''+target_table+'''
    TargetColumn
    ******/

    declare @BatchID int

        set nocount on
        declare @STM table(ColumnName varchar(50))
        insert into @STM (ColumnName) values\n'''+file+'''

        -- get columns with differs(if exists)
        declare @errorColumns varchar(755) = ''
        declare @countFlag int = 0

        select
        @errorColumns = @errorColumns + COLUMN_NAME + '; '
        from INFORMATION_SCHEMA.COLUMNS
        where TABLE_NAME='{}' and TABLE_SCHEMA='outbound' and COLUMN_NAME not in (select * from @STM)

        --set @countFlag = 1 if count(stm) <> count(table)
        if((select count(*) from @STM) <> (select count(*) from INFORMATION_SCHEMA.COLUMNS where TABLE_NAME='{}'))
            set @countFlag = 1

         --check conditions, create error message, raise error
        if (select len(@errorColumns)) <> 0 or @countFlag = 1
        begin
            declare @errorMsg varchar(755) = ''

            if (select len(@errorColumns)) <> 0
                set @errorMsg = 'Column(s) name are differ from STM. Please check table columns: ' + @errorColumns

            if @countFlag = 1
                set @errorMsg = 'Number of columns are differ from STM. ' + @errorMsg

            raiserror(@errorMsg, 16, -99)
        end '''.format(target_table,target_table))
    f.close()




def columns_type_check(file_name,date,target_table,typecolumns,main_path,link):
        # print target_table
        with open(main_path+'\Staging - {} - Columns type check.sql'.format(target_table), 'w') as d:
            d.write('''
/****** STM: '''+file_name+''' ver:  Script Date: '''+str(date)+'''
STM Link: '''+link+'''

SourceTable
SourceColumn

TargetTable '''+target_table+'''
TargetColumn
******/


    declare @BatchID int


    declare @Table table(ColumnName varchar(50), DataType varchar(10))
    insert into @Table (ColumnName, DataType) values\n'''+typecolumns+'''

    -- get columns with differ data type(if exists)
    declare @errorColumns varchar(755) = ''

    select
    @errorColumns = @errorColumns + COLUMN_NAME + '; '
    from INFORMATION_SCHEMA.COLUMNS join @Table on COLUMN_NAME=ColumnName
    where TABLE_NAME='{}' and TABLE_SCHEMA='outbound' and DATA_TYPE <> DataType

    -- check columns, create error message, raise error if condition == true
    if (select len(@errorColumns)) <> 0
    begin
        declare @errorMsg varchar(755) = ('Data type(s) is differ from STM. Columns: '+(select @errorColumns))
        raiserror(@errorMsg, 16, -99)
    end'''.format(target_table))
        d.close()


def metadata(file_name,date,target_table, metacolumns,main_path,link):
    with open(main_path+'\Staging - {} - Metadata check.sql'.format(target_table), 'w') as c:
        c.write('''/****** STM: '''+file_name+''' ver:  Script Date: '''+str(date)+'''

STM Link: '''+link+'''
SourceTable
SourceColumn - all

TargetTable '''+target_table+'''
TargetColumn -  all     ******/

        set nocount on

        declare @STM table(ColumnName varchar(50), Nullability varchar(50))
        insert into @STM (ColumnName, Nullability) values\n'''+metacolumns+'''

        -- get columns with differs(if exists)
        declare @errorColumns varchar(755) = ''

        select
        @errorColumns = @errorColumns + COLUMN_NAME + '; '
        from @STM t1 join
        (select COLUMN_NAME, IIF(IS_NULLABLE = 'NO', 'Not Nullable', 'Nullable') as IS_NULLABLE
        from dm_staging.INFORMATION_SCHEMA.COLUMNS
        where TABLE_NAME='{}' and TABLE_SCHEMA='outbound') t2
        on t1.ColumnName = t2.COLUMN_NAME and t1.Nullability <> t2.IS_NULLABLE

         --check conditions, create error message, raise error
        if (select len(@errorColumns)) <> 0
        begin
            declare @errorMsg varchar(755) = ''
            set @errorMsg = 'Column(s) nullability constraint are differ from STM. Please check table columns: ' + @errorColumns
            raiserror(@errorMsg, 16, -99)
        end'''.format(target_table))
    c.close()

def isNumericCheck(file_name,date,source_table,source_column,target_table,target_column,target_length,main_path,link):
    with open(main_path+'\Staging - {} - {} - isNumeric check.sql'.format(target_table, target_column), 'w') as f:
        f.write('''
/******STM: ''' + file_name + ''' ver:  Script Date:''' + str(date) + '''
STM Link: '''+link+'''
 SourceTable {}
 SourceColumn {}

 TargetTable  {}
 TargetColumn {}
******/
declare @BatchID int = ?
if exists(
  select *
  from dm_staging.outbound.{}
  where TRY_CAST(dm_staging.outbound.{}.{}  as numeric({})) is null
	   or dm_staging.outbound.{}.{} not like '%.%'
	   and BatchID = @BatchID
)
  raiserror('[{}] should contain only number values;', 16, -99)'''.format(source_table, source_column,
                                                                                target_table, target_column,
                                                                                target_table,target_table,target_column,target_length,target_table,target_column,target_column))
        f.close()



def columns_check(file_name,date,file,target_table,main_path,link):
    with open(main_path+'\Staging - {} - columns check.sql'.format(target_table), 'w') as f:
        f.write('''/****** STM:'''+file_name+''' ver:  Script Date: '''+str(date)+'''
       STM Link: '''+link+'''
    SourceTable
    SourceColumn
    TargetTable  '''+target_table+'''
    TargetColumn
    ******/

    declare @BatchID int

        set nocount on
        declare @STM table(ColumnName varchar(50))
        insert into @STM (ColumnName) values\n'''+file+'''

        -- get columns with differs(if exists)
        declare @errorColumns varchar(755) = ''
        declare @countFlag int = 0

        select
        @errorColumns = @errorColumns + COLUMN_NAME + '; '
        from INFORMATION_SCHEMA.COLUMNS
        where TABLE_NAME='{}' and TABLE_SCHEMA='outbound' and COLUMN_NAME not in (select * from @STM)

        --set @countFlag = 1 if count(stm) <> count(table)
        if((select count(*) from @STM) <> (select count(*) from INFORMATION_SCHEMA.COLUMNS where TABLE_NAME='{}'))
            set @countFlag = 1

         --check conditions, create error message, raise error
        if (select len(@errorColumns)) <> 0 or @countFlag = 1
        begin
            declare @errorMsg varchar(755) = ''

            if (select len(@errorColumns)) <> 0
                set @errorMsg = 'Column(s) name are differ from STM. Please check table columns: ' + @errorColumns

            if @countFlag = 1
                set @errorMsg = 'Number of columns are differ from STM. ' + @errorMsg

            raiserror(@errorMsg, 16, -99)
        end '''.format(target_table,target_table))
    f.close()


def column_comparison(file_name,date,target_table,target_column,main_path,link,source_table,source_column):
    with open(main_path + '\Staging - {} - {} - column comparison.sql'.format(target_table, target_column), 'w') as f:
        f.write('''/****** STM:''' + file_name + ''' ver:  Script Date: ''' + str(date) + '''
STM Link: '''+link+'''
   SourceTable '''+source_table+'''
   SourceColumn '''+source_column+'''

   TargetTable   '''+target_table+'''
   TargetColumn  '''+target_column+'''
   ******/

declare @BatchID int =?


;with [TransformedSource] as (
			select *
		    from
),

[Target]
as (
		select '''+target_column+''' as value
	from dm_staging.outbound.'''+target_table+'''
    where BatchID = @BatchID

    union all

    select '''+target_column+''' as value
	from dm_staging.outbound.'''+target_table+'''_rejected
    where BatchID = @BatchID

)
---------------------------------------------------

select Error = 'Error: Record from Source doesnt exists in Target' , *
from (
  select * from [TransformedSource]
  except
  select * from [Target]
) e1

union all

select Error = 'Error: Record from Target doesnt exists in Source', *
from (
  select * from [Target]
  except
  select * from [TransformedSource]
) e2

declare @Rows int = @@Rowcount
if @Rows>0   raiserror(\''''+target_column+''' contains invalid data;', 16, -99)

   ''')
    f.close()


