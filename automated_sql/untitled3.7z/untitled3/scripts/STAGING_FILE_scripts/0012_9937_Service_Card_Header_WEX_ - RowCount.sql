/****** STM:0012_EFCPRMS_9937_Service_Card_Header_WEX_Staging_File_STM.xlsx ver:  Script Date:2016-09-08
    STM Link: https: https://elementfinancialcorporation.sharepoint.com/EPAM-EFC-PRMS/DocCentre/_layouts/15/WopiFrame.aspx?sourcedoc=%7B81E2431E-8622-413F-8766-283C0B0FDD6E%7D&file=0018_EFCPRMS_8122_Profile_Landing_Staging_STM.xlsx&action=default
    

    SourceTable Service_Card_Header
    SourceColumn  N/A

    TargetTable
    TargetColumn   ******/

    declare @BatchID varchar(10)

    if exists(
    select count(*) from dm_staging.outbound.Service_Card_Header
    except
    select count(*) from [dm_test].[dbo].[0012_9937_Service_Card_Header_WEX_ALL]
        )
    raiserror('Service_Card_Header.[RowCount] <> Output.[RowCount];', 16, -99)