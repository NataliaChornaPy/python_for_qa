/****** STM:0012_EFCPRMS_9937_Service_Card_Header_WEX_Staging_File_STM.xlsx ver:  Script Date:2016-09-08
STM Link:https://elementfinancialcorporation.sharepoint.com/EPAM-EFC-PRMS/DocCentre/_layouts/15/WopiFrame.aspx?sourcedoc=%7B81E2431E-8622-413F-8766-283C0B0FDD6E%7D&file=0018_EFCPRMS_8122_Profile_Landing_Staging_STM.xlsx&action=default
    
SourceTable   ..Service_Card_Header
SourceColumn

TargetTable   0012_9937_Service_Card_Header_WEX_ALL
TargetColumn ******/

declare @BatchID int

-- Select column for test from source.
;with [Source] as
    (select           isnull(convert(varchar(255),InsertTypeCode), '') as [InsertTypeCode],
           isnull(convert(varchar(255),InsertID), '') as [InsertID],
           isnull(convert(varchar(255),ServiceCardTypeCode), '') as [ServiceCardTypeCode],
           isnull(convert(varchar(255),Breakdown), '') as [Breakdown],
           isnull(convert(varchar(255),ClientNumber), '') as [ClientNumber],
           isnull(convert(varchar(255),CorpCode), '') as [CorpCode],
           isnull(convert(varchar(255),Allowed), '') as [Allowed],
           isnull(convert(varchar(255),AutoOrder), '') as [AutoOrder],
           isnull(convert(varchar(255),ProductionClass), '') as [ProductionClass],
           isnull(convert(varchar(255),MailedTo), '') as [MailedTo],
           isnull(convert(varchar(255),CompanyName), '') as [CompanyName],
           isnull(convert(varchar(255),LastTransactionDate), '') as [LastTransactionDate],
           isnull(convert(varchar(255),StatusIndicator), '') as [StatusIndicator],
           isnull(convert(varchar(255),FourthLineImprint), '') as [FourthLineImprint],
           isnull(convert(varchar(255),MultipleCards), '') as [MultipleCards],
           isnull(convert(varchar(255),RenewalCycleCode), '') as [RenewalCycleCode],
           isnull(convert(varchar(255),ExpirationDate), '') as [ExpirationDate],
           isnull(convert(varchar(255),ClientPlasticIndicator), '') as [ClientPlasticIndicator],
           isnull(convert(varchar(255),AdditionalLine), '') as [AdditionalLine],
           isnull(convert(varchar(255),ImprintCode), '') as [ImprintCode],
           isnull(convert(varchar(255),CustomCode), '') as [CustomCode],
           isnull(convert(varchar(255),OTRProcess), '') as [OTRProcess],
           isnull(convert(varchar(255),HighestAllowedMailing), '') as [HighestAllowedMailing],
           isnull(convert(varchar(255),StandardMail), '') as [StandardMail],
           isnull(convert(varchar(255),OvernightCarrier), '') as [OvernightCarrier],
           isnull(convert(varchar(255),OvernightAccount), '') as [OvernightAccount],
           isnull(convert(varchar(255),Limit), '') as [Limit],
           isnull(convert(varchar(255),DailyPIN), '') as [DailyPIN],
           isnull(convert(varchar(255),PINControl), '') as [PINControl],
           isnull(convert(varchar(255),ReturnRenewTo), '') as [ReturnRenewTo],
           isnull(convert(varchar(255),UniqueID), '') as [UniqueID],
           isnull(convert(varchar(255),BackIssueDays), '') as [BackIssueDays],
           isnull(convert(varchar(255),Cycle), '') as [Cycle],
           isnull(convert(varchar(255),NextRenewalDate), '') as [NextRenewalDate],
           isnull(convert(varchar(255),LeadDays), '') as [LeadDays],
           isnull(convert(varchar(255),SortCode), '') as [SortCode],
           isnull(convert(varchar(255),ReturnNewTo), '') as [ReturnNewTo]

    from ..Service_Card_Header
),

-- Select column for test from target table.
[Target] as
(select            [Insert Type Code],
           [Insert ID],
           [Service Card Type Code],
           [Breakdown],
           [Client No],
           [Corporate Code],
           [Allowed],
           [Auto order],
           [Production class],
           [Mailed To],
           [Company Name],
           [Last Transaction Date],
           [Status Indicator],
           [Fourth Line Imprint],
           [Multiple Cards],
           [Renewal Cycle Code],
           [Expiration Date],
           [Client Plastic Indicator],
           [Additional Line],
           [Imprint Code],
           [Custom code],
           [OTR Process],
           [Highest Allowed mailing],
           [Standard Mail],
           [Overnight Carrier],
           [Overnight Account],
           [Limit],
           [Daily PIN],
           [PIN Control],
           [Return Renew To],
           [Unique ID],
           [Back Issue Days],
           [Cycle],
           [Next Renewal Date],
           [Lead days],
           [Sort Code],
           [Return New To]
from [dm_test].[dbo].[0012_9937_Service_Card_Header_WEX_ALL]

)
-----------------------------------------------
-- Select incorrect data

select 'Error: Record from Source doesnt exists in Target'Error , * from
( -- Everything from TransformedSource, except Target
       select * from [Source]
       except
       select * from [Target]
) e1
union all
select 'Error: Record from Target doesnt exists in Source'Error , * from
(-- Everything from Target, except TransformedSource
       select * from [Target]
       except
       select * from [Source]
) e2
declare @Rows int = @@Rowcount,
@Message varchar(255)
set @Message ='Columns contain invalid data;'+ convert(varchar(25),@Rows)
if @Rows>0   raiserror(@Message, 16, -99)

 