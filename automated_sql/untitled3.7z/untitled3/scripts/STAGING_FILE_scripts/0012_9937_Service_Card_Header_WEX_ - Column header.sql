/****** STM:0012_EFCPRMS_9937_Service_Card_Header_WEX_Staging_File_STM.xlsx ver:  Script Date:2016-09-08
STM Link: https://elementfinancialcorporation.sharepoint.com/EPAM-EFC-PRMS/DocCentre/_layouts/15/WopiFrame.aspx?sourcedoc=%7B81E2431E-8622-413F-8766-283C0B0FDD6E%7D&file=0018_EFCPRMS_8122_Profile_Landing_Staging_STM.xlsx&action=default
    
SourceTable   ..Service_Card_Header
TargetTable   0012_9937_Service_Card_Header_WEX_ALL

TargetTable
TargetColumn   ******/

declare @BatchID int

set nocount on
declare @STM_O table(ColumnName varchar(50))
insert into @STM_O (ColumnName) values 
           ('Insert Type Code'),
           ('Insert ID'),
           ('Service Card Type Code'),
           ('Breakdown'),
           ('Client No'),
           ('Corporate Code'),
           ('Allowed'),
           ('Auto order'),
           ('Production class'),
           ('Mailed To'),
           ('Company Name'),
           ('Last Transaction Date'),
           ('Status Indicator'),
           ('Fourth Line Imprint'),
           ('Multiple Cards'),
           ('Renewal Cycle Code'),
           ('Expiration Date'),
           ('Client Plastic Indicator'),
           ('Additional Line'),
           ('Imprint Code'),
           ('Custom code'),
           ('OTR Process'),
           ('Highest Allowed mailing'),
           ('Standard Mail'),
           ('Overnight Carrier'),
           ('Overnight Account'),
           ('Limit'),
           ('Daily PIN'),
           ('PIN Control'),
           ('Return Renew To'),
           ('Unique ID'),
           ('Back Issue Days'),
           ('Cycle'),
           ('Next Renewal Date'),
           ('Lead days'),
           ('Sort Code'),
           ('Return New To')

-- get columns with differs(if exists)
declare @errorColumns varchar(755) = ''
declare @countFlag int = 0

select
@errorColumns = @errorColumns + COLUMN_NAME + '; '
from INFORMATION_SCHEMA.COLUMNS
where TABLE_NAME like '%Service_Card_Header%' and TABLE_SCHEMA='dbo' and COLUMN_NAME not in (select * from @STM_O)

--set @countFlag = 1 if count(stm) <> count(table)
if((select count(*) from @STM_O) <> (select count(*) from INFORMATION_SCHEMA.COLUMNS where TABLE_NAME like '%Service_Card_Header%'))
	set @countFlag = 1

 --check conditions, create error message, raise error
if (select len(@errorColumns)) <> 0 or @countFlag = 1
begin
	declare @errorMsg varchar(755) = ''

	if (select len(@errorColumns)) <> 0
		set @errorMsg = 'Column(s) name are differ from STM. Please check table columns: ' + @errorColumns

	if @countFlag = 1
		set @errorMsg = 'Number of columns are differ from STM. ' + @errorMsg

	raiserror(@errorMsg, 16, -99)
end


 